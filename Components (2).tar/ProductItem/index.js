// ProductItem.js
import './index.css'

const ProductItem = ({product}) => {
  if (!product) {
    return <div>Error: Product data is missing</div>
  }

  return (
    <div className="product-item">
      <div className="card-wrap">
        <div className="card">
          <div className="images">
            <img
              className="product-img"
              src={product.image}
              alt={product.name}
            />
          </div>
          <h3>{product.name}</h3>
          <p>{product.description}</p>
          <p>Price: ${product.price}</p>
          {/* Add more details or actions here */}
        </div>
      </div>
    </div>
  )
}

export default ProductItem
