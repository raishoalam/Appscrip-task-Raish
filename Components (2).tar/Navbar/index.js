// Navbar.js
import React, {useState} from 'react'
import {GoChevronDown} from 'react-icons/go'
import {CiSearch, CiHeart, CiUser} from 'react-icons/ci'
import {LiaLessThanSolid} from 'react-icons/lia'

import {BsBagDash} from 'react-icons/bs'
import './index.css'

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false)

  const toggleMenu = () => {
    setIsOpen(!isOpen)
  }

  const closeMenu = () => {
    setIsOpen(false)
  }

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <div className="nav-logo">
          <div className="navbar-logo">LOGO</div>
        </div>
        <div className={`navbar-links ${isOpen ? 'active' : ''}`}>
          <ul className="nav-section">
            <li>
              <a href="#home" onClick={closeMenu}>
                <CiSearch className="nav-icons" />
              </a>
            </li>

            <li>
              <a href="#skills" onClick={closeMenu}>
                <CiHeart className="nav-icons" />
              </a>
            </li>
            <li>
              <a href="#stories" onClick={closeMenu}>
                <BsBagDash className="nav-icons" />
              </a>
            </li>

            <li>
              <a href="#contact" onClick={closeMenu}>
                <CiUser className="nav-icons" />
              </a>
            </li>

            <li>
              <h1 className="lang">
                ENG <GoChevronDown className="nav-icons" />
              </h1>
            </li>
          </ul>
        </div>
        <div
          className="navbar-toggle"
          onClick={toggleMenu}
          role="button"
          tabIndex={0}
        >
          <i className={`fas ${isOpen ? 'fa-times' : 'fa-bars'}`} />
        </div>
      </div>
      <div className="logos">
        <a href="#contact" onClick={closeMenu}>
          SHOP
        </a>
        <a href="#contact" onClick={closeMenu}>
          SKILLS
        </a>
        <a href="#contact" onClick={closeMenu}>
          STORIES
        </a>
        <a href="#contact" onClick={closeMenu}>
          ABOUT
        </a>
        <a href="#contact" onClick={closeMenu}>
          CONTACT US
        </a>
      </div>
      <hr />
      <div className="nav-headers">
        <h1 className="nav-heading">DISCOVER OUR PRODUCTS</h1>
        <p className="nav-pra">
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industry standard dummy text ever
          since the 1500s, when an unknown printer took a galley of type and
          scrambled it to make a type specimen book. It has survived not only
          five centuries
        </p>
      </div>
      <hr />
      <div className="items">
        <h1 className="nav-pra1">3425 ITEMS</h1>
        <a href="#contact" onClick={closeMenu}>
          <LiaLessThanSolid className="nav-icons1" /> HIDE FILTERS
        </a>

        <h1 className="nav-pra1">
          RECOMMENDED <GoChevronDown className="nav-icons1" />
        </h1>
      </div>
      <hr />
    </nav>
  )
}

export default Navbar
