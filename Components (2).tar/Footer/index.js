// Footer.js
import './index.css'

const Footer = () => (
  <footer className="footer">
    <div className="footer-section">
      <h1 className="footer-heading">BE THE FIRST TO KNOW</h1>
    </div>
  </footer>
)

export default Footer
