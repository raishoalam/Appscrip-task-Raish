import {GoChevronDown} from 'react-icons/go' // Sidebar.js
import './index.css'
import {FaRegSquare} from 'react-icons/fa'

const Sidebar = () => (
  <div className="sidebar">
    <ul>
      <li>
        <a href="#home">
          <FaRegSquare className="side-icon" />
          CUSTOMIZBLE
        </a>
      </li>
      <hr />
      <li>
        <div className="drop-cont">
          <div>
            <a href="#shop">IDEAL FOR</a>
            <p className="side-pra">All</p>
          </div>
          <GoChevronDown />
        </div>
      </li>
      <hr />
      <li>
        <div className="drop-cont">
          <div>
            <a href="#skills">OCCASION</a>
            <p className="side-pra">All</p>
          </div>
          <GoChevronDown />
        </div>
      </li>
      <hr />
      <li>
        <div className="drop-cont">
          <div>
            <a href="#stories">WORK</a>
            <p className="side-pra">All</p>
          </div>
          <GoChevronDown />
        </div>
      </li>
      <hr />
      <li>
        <div className="drop-cont">
          <div>
            <a href="#about">FABRIC</a>
            <p className="side-pra">All</p>
          </div>
          <GoChevronDown />
        </div>
      </li>
      <hr />
      <li>
        <li>
          <div className="drop-cont">
            <div>
              <a href="#about">SEGMENT</a>
              <p className="side-pra">All</p>
            </div>
            <GoChevronDown />
          </div>
        </li>
        <hr />
        <li>
          <li>
            <div className="drop-cont">
              <div>
                <a href="#about">SEGMENT</a>
                <p className="side-pra">All</p>
              </div>
              <GoChevronDown />
            </div>
          </li>
          <hr />
          <li>
            <div className="drop-cont">
              <div>
                <a href="#about">SUITABLE FOR</a>
                <p className="side-pra">All</p>
              </div>
              <GoChevronDown />
            </div>
          </li>
          <hr />
          <li>
            <div className="drop-cont">
              <div>
                <a href="#about">RAW MATERIALS</a>
                <p className="side-pra">All</p>
              </div>
              <GoChevronDown />
            </div>
          </li>
          <hr />
          <li>
            <div className="drop-cont">
              <div>
                <a href="#about">PATTERN</a>
                <p className="side-pra">All</p>
              </div>
              <GoChevronDown />
            </div>
          </li>
          <hr />
        </li>
        <div className="drop-cont">
          <div>
            <a href="#contact">Contact Us</a>
            <p className="side-pra">All</p>
          </div>
          <GoChevronDown />
        </div>
      </li>
      <hr />
    </ul>
  </div>
)

export default Sidebar
